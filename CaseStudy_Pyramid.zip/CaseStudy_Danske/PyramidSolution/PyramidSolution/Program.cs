﻿using PyramidSolution.BL;
using PyramidSolution.FileManipulation;
using PyramidSolution.FileValidation;
using PyramidSolution.GUI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using Unity;

namespace PyramidSolution
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            IUnityContainer containerObj = new UnityContainer();
            containerObj.RegisterType<IPyramidLogic, PyramidLogic>();
            containerObj.RegisterType<IProcessPyramidFile, ProcessPyramidFile>();
            containerObj.RegisterType<IValidateFile, ValidateFile>();
            
            Application.Run(new frmPyramid(containerObj.Resolve<IPyramidLogic>()));
        }
    }
}
